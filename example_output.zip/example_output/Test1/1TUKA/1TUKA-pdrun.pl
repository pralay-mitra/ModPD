#!/usr/bin/perl

`mkdir -p /tmp/abantika/base-Test1-1TUKA`;
chdir '/tmp/abantika/base-Test1-1TUKA';
`/home/abantika/Modular_Protein_Design/output/Test1/lib/design_single_protein /apps/EvoDesign/utility/scwrl4 /apps/EvoDesign/utility/foldx_Linux.tar__FILES /apps/EvoDesign/utility/dssp/dsspcmbi /apps/PDB abantika Test1 /home/abantika/Publication_ready/utility/TMalign 10 100 20 1TUKA /home/abantika/Modular_Protein_Design/output /home/abantika/Modular_Protein_Design >runout.txt 2>runerr.txt`;
`cp runout.txt runerr.txt /home/abantika/Modular_Protein_Design/output/Test1/1TUKA`;
`sync`;
`sync`;
sleep 10;
`rm *`;
`rmdir /tmp/abantika/base-Test1-1TUKA`;
sleep 10;
`rm -rf /home/abantika/Modular_Protein_Design/output/Test1/lib`;
